/*jQuery.fn.mytoolbox = function() {
    return this.each(function() {
		//alert(this.id);
		jQuery(this).click(function () {
					alert(this.id);
				});		
    });
};*/
;(function($) {
/*    $.fn.mytoolbox = function() {
        return this.each(function() {
            $(this).click(function () {
                alert(this.id);
            });
        });
    };
*/	
	$.fn.mytoolbox = function(settings) {
		var _defaultSettings = {
			bind: 'click',
			callback: function () {
				alert(this.id);
			}
		};
		var _settings = $.extend(_defaultSettings, settings);
		return this.each(function() {
			$(this).click(_settings.callback);
		});
	};
	
})(jQuery);