#!/bin/bash
SRC=$1

# CAN A
# CAN B, pack 1,4,5,12
grep --color="auto" \
\
    -e "18FF0822x" \
    -e "1CECFF22x" \
    -e "1CEBFF22x" \
\
    -e "1832A0C1x" \
    -e "1833A0C1x" \
    -e "1834A0C1x" \
    -e "1835A0C1x" \
    -e "1836A0C1x" \
    -e "1837A0C1x" \
    -e "1850A0C1x" \
    -e "1851A0C1x" \
    -e "1852A0C1x" \
    -e "1853A0C1x" \
\
    -e "1832A0C1x" \
    -e "1833A0C1x" \
    -e "1834A0C1x" \
    -e "1835A0C1x" \
    -e "1836A0C1x" \
    -e "1837A0C1x" \
    -e "1850A0C1x" \
    -e "1851A0C1x" \
    -e "1852A0C1x" \
    -e "1853A0C1x" \
\
    -e "1832A0C4x" \
    -e "1833A0C4x" \
    -e "1834A0C4x" \
    -e "1835A0C4x" \
    -e "1836A0C4x" \
    -e "1837A0C4x" \
    -e "1850A0C4x" \
    -e "1851A0C4x" \
    -e "1852A0C4x" \
    -e "1853A0C4x" \
\
    -e "1832A0C5x" \
    -e "1833A0C5x" \
    -e "1834A0C5x" \
    -e "1835A0C5x" \
    -e "1836A0C5x" \
    -e "1837A0C5x" \
    -e "1850A0C5x" \
    -e "1851A0C5x" \
    -e "1852A0C5x" \
    -e "1853A0C5x" \
\
    -e "1832A0CCx" \
    -e "1833A0CCx" \
    -e "1834A0CCx" \
    -e "1835A0CCx" \
    -e "1836A0CCx" \
    -e "1837A0CCx" \
    -e "1850A0CCx" \
    -e "1851A0CCx" \
    -e "1852A0CCx" \
    -e "1853A0CCx" \
\
$SRC > $SRC".filtered"

exit 0
