#include <QtQml/qqmlprivate.h>
#include <QtCore/qdir.h>
#include <QtCore/qurl.h>

static const unsigned char qt_resource_tree[] = {
0,
0,0,0,0,2,0,0,0,2,0,0,0,1,0,0,0,
96,0,2,0,0,0,26,0,0,0,6,0,0,0,8,0,
2,0,0,0,1,0,0,0,3,0,0,0,28,0,2,0,
0,0,2,0,0,0,4,0,0,0,46,0,0,0,0,0,
1,0,0,0,0,0,0,0,72,0,0,0,0,0,1,0,
0,0,0,0,0,3,158,0,2,0,0,0,2,0,0,0,
50,0,0,5,108,0,2,0,0,0,2,0,0,0,48,0,
0,1,2,0,0,0,0,0,1,0,0,0,0,0,0,5,
216,0,2,0,0,0,3,0,0,0,45,0,0,1,106,0,
0,0,0,0,1,0,0,0,0,0,0,5,190,0,0,0,
0,0,1,0,0,0,0,0,0,1,146,0,0,0,0,0,
1,0,0,0,0,0,0,4,238,0,0,0,0,0,1,0,
0,0,0,0,0,5,10,0,2,0,0,0,2,0,0,0,
43,0,0,2,76,0,0,0,0,0,1,0,0,0,0,0,
0,1,190,0,0,0,0,0,1,0,0,0,0,0,0,0,
108,0,0,0,0,0,1,0,0,0,0,0,0,6,108,0,
2,0,0,0,5,0,0,0,38,0,0,0,222,0,0,0,
0,0,1,0,0,0,0,0,0,7,42,0,0,0,0,0,
1,0,0,0,0,0,0,2,42,0,0,0,0,0,1,0,
0,0,0,0,0,3,106,0,0,0,0,0,1,0,0,0,
0,0,0,0,152,0,0,0,0,0,1,0,0,0,0,0,
0,1,82,0,0,0,0,0,1,0,0,0,0,0,0,6,
74,0,0,0,0,0,1,0,0,0,0,0,0,1,212,0,
0,0,0,0,1,0,0,0,0,0,0,1,250,0,0,0,
0,0,1,0,0,0,0,0,0,7,0,0,0,0,0,0,
1,0,0,0,0,0,0,2,98,0,2,0,0,0,6,0,
0,0,32,0,0,0,192,0,0,0,0,0,1,0,0,0,
0,0,0,1,46,0,0,0,0,0,1,0,0,0,0,0,
0,2,150,0,0,0,0,0,1,0,0,0,0,0,0,2,
230,0,0,0,0,0,1,0,0,0,0,0,0,2,118,0,
0,0,0,0,1,0,0,0,0,0,0,2,194,0,0,0,
0,0,1,0,0,0,0,0,0,3,74,0,0,0,0,0,
1,0,0,0,0,0,0,3,22,0,0,0,0,0,1,0,
0,0,0,0,0,6,206,0,0,0,0,0,1,0,0,0,
0,0,0,6,134,0,0,0,0,0,1,0,0,0,0,0,
0,6,230,0,0,0,0,0,1,0,0,0,0,0,0,6,
178,0,0,0,0,0,1,0,0,0,0,0,0,6,158,0,
0,0,0,0,1,0,0,0,0,0,0,5,34,0,0,0,
0,0,1,0,0,0,0,0,0,5,70,0,0,0,0,0,
1,0,0,0,0,0,0,6,20,0,0,0,0,0,1,0,
0,0,0,0,0,5,246,0,0,0,0,0,1,0,0,0,
0,0,0,6,50,0,0,0,0,0,1,0,0,0,0,0,
0,5,124,0,0,0,0,0,1,0,0,0,0,0,0,5,
164,0,0,0,0,0,1,0,0,0,0,0,0,3,170,0,
2,0,0,0,4,0,0,0,57,0,0,4,60,0,2,0,
0,0,5,0,0,0,52,0,0,4,148,0,0,0,0,0,
1,0,0,0,0,0,0,4,182,0,0,0,0,0,1,0,
0,0,0,0,0,4,114,0,0,0,0,0,1,0,0,0,
0,0,0,4,80,0,0,0,0,0,1,0,0,0,0,0,
0,4,204,0,0,0,0,0,1,0,0,0,0,0,0,4,
28,0,0,0,0,0,1,0,0,0,0,0,0,3,252,0,
0,0,0,0,1,0,0,0,0,0,0,3,220,0,0,0,
0,0,1,0,0,0,0,0,0,3,188,0,0,0,0,0,
1,0,0,0,0};
static const unsigned char qt_resource_names[] = {
0,
1,0,0,0,47,0,47,0,7,0,120,191,123,0,106,0,
98,0,81,0,117,0,105,0,99,0,107,0,6,4,158,137,
179,0,67,0,104,0,97,0,114,0,116,0,115,0,10,8,
157,231,252,0,81,0,67,0,104,0,97,0,114,0,116,0,
46,0,113,0,109,0,108,0,9,14,137,222,51,0,81,0,
67,0,104,0,97,0,114,0,116,0,46,0,106,0,115,0,
3,0,0,120,60,0,113,0,109,0,108,0,19,7,185,4,
156,0,80,0,101,0,100,0,97,0,108,0,71,0,97,0,
117,0,103,0,101,0,83,0,116,0,121,0,108,0,101,0,
46,0,113,0,109,0,108,0,17,10,159,131,252,0,84,0,
117,0,114,0,110,0,73,0,110,0,100,0,105,0,99,0,
97,0,116,0,111,0,114,0,46,0,113,0,109,0,108,0,
12,15,202,172,156,0,68,0,105,0,97,0,103,0,110,0,
111,0,115,0,101,0,46,0,113,0,109,0,108,0,15,9,
39,121,92,0,86,0,101,0,104,0,105,0,99,0,108,0,
101,0,73,0,110,0,102,0,111,0,46,0,113,0,109,0,
108,0,19,0,155,123,92,0,84,0,97,0,99,0,104,0,
111,0,109,0,101,0,116,0,101,0,114,0,83,0,116,0,
121,0,108,0,101,0,46,0,113,0,109,0,108,0,15,15,
228,235,188,0,86,0,97,0,108,0,117,0,101,0,83,0,
111,0,117,0,114,0,99,0,101,0,46,0,113,0,109,0,
108,0,9,12,97,242,156,0,76,0,111,0,103,0,79,0,
110,0,46,0,113,0,109,0,108,0,17,3,221,47,156,0,
66,0,97,0,116,0,116,0,101,0,114,0,121,0,83,0,
116,0,97,0,116,0,117,0,115,0,46,0,113,0,109,0,
108,0,19,5,171,242,60,0,73,0,99,0,111,0,110,0,
68,0,101,0,115,0,99,0,114,0,105,0,112,0,116,0,
105,0,111,0,110,0,46,0,113,0,109,0,108,0,8,7,
70,95,92,0,84,0,112,0,109,0,115,0,46,0,113,0,
109,0,108,0,16,13,135,77,252,0,72,0,109,0,105,0,
68,0,97,0,115,0,104,0,98,0,111,0,97,0,114,0,
100,0,46,0,113,0,109,0,108,0,21,14,1,166,188,0,
66,0,97,0,116,0,116,0,101,0,114,0,121,0,68,0,
101,0,112,0,108,0,111,0,121,0,109,0,101,0,110,0,
116,0,46,0,113,0,109,0,108,0,14,10,89,254,28,0,
100,0,97,0,115,0,104,0,119,0,105,0,110,0,100,0,
111,0,119,0,46,0,113,0,109,0,108,0,8,6,103,97,
28,0,66,0,111,0,111,0,116,0,46,0,113,0,109,0,
108,0,7,15,10,182,89,0,104,0,105,0,115,0,116,0,
111,0,114,0,121,0,13,5,79,17,156,0,83,0,121,0,
115,0,116,0,101,0,109,0,76,0,111,0,103,0,46,0,
113,0,109,0,108,0,19,0,174,98,28,0,67,0,101,0,
108,0,108,0,65,0,108,0,97,0,114,0,109,0,82,0,
101,0,99,0,111,0,114,0,100,0,46,0,113,0,109,0,
108,0,15,7,163,99,220,0,65,0,108,0,97,0,114,0,
109,0,82,0,101,0,99,0,111,0,114,0,100,0,46,0,
113,0,109,0,108,0,21,4,196,2,28,0,86,0,101,0,
104,0,105,0,99,0,108,0,101,0,73,0,110,0,102,0,
111,0,82,0,101,0,99,0,111,0,114,0,100,0,46,0,
113,0,109,0,108,0,23,15,21,70,220,0,67,0,104,0,
97,0,114,0,103,0,101,0,84,0,114,0,105,0,112,0,
112,0,101,0,100,0,82,0,101,0,99,0,111,0,114,0,
100,0,46,0,113,0,109,0,108,0,13,10,214,116,92,0,
65,0,108,0,97,0,114,0,109,0,83,0,116,0,97,0,
116,0,46,0,113,0,109,0,108,0,23,10,109,113,124,0,
68,0,97,0,115,0,104,0,98,0,111,0,97,0,114,0,
100,0,71,0,97,0,117,0,103,0,101,0,83,0,116,0,
121,0,108,0,101,0,46,0,113,0,109,0,108,0,3,0,
0,107,165,0,101,0,99,0,117,0,6,6,132,131,87,0,
97,0,110,0,97,0,108,0,111,0,103,0,13,14,13,97,
252,0,80,0,99,0,117,0,65,0,110,0,97,0,108,0,
111,0,103,0,46,0,113,0,109,0,108,0,13,10,13,97,
220,0,86,0,99,0,117,0,65,0,110,0,97,0,108,0,
111,0,103,0,46,0,113,0,109,0,108,0,13,2,13,94,
28,0,66,0,99,0,117,0,65,0,110,0,97,0,108,0,
111,0,103,0,46,0,113,0,109,0,108,0,13,1,217,94,
28,0,66,0,109,0,115,0,65,0,110,0,97,0,108,0,
111,0,103,0,46,0,113,0,109,0,108,0,7,10,254,10,
188,0,100,0,105,0,103,0,105,0,116,0,97,0,108,0,
14,15,74,169,156,0,80,0,99,0,117,0,68,0,105,0,
103,0,105,0,116,0,97,0,108,0,46,0,113,0,109,0,
108,0,14,15,74,167,28,0,86,0,99,0,117,0,68,0,
105,0,103,0,105,0,116,0,97,0,108,0,46,0,113,0,
109,0,108,0,14,2,138,186,124,0,66,0,109,0,115,0,
68,0,105,0,103,0,105,0,116,0,97,0,108,0,46,0,
113,0,109,0,108,0,8,9,166,97,124,0,68,0,99,0,
100,0,99,0,46,0,113,0,109,0,108,0,14,15,74,186,
28,0,66,0,99,0,117,0,68,0,105,0,103,0,105,0,
116,0,97,0,108,0,46,0,113,0,109,0,108,0,11,6,
6,69,92,0,72,0,105,0,115,0,116,0,111,0,114,0,
121,0,46,0,113,0,109,0,108,0,9,6,69,115,211,0,
105,0,99,0,111,0,110,0,95,0,100,0,101,0,115,0,
99,0,15,11,165,51,60,0,67,0,104,0,97,0,114,0,
103,0,101,0,77,0,111,0,100,0,101,0,108,0,46,0,
113,0,109,0,108,0,16,14,88,153,252,0,67,0,111,0,
110,0,116,0,97,0,99,0,116,0,77,0,111,0,100,0,
101,0,108,0,46,0,113,0,109,0,108,0,5,0,122,192,
37,0,115,0,116,0,121,0,108,0,101,0,17,0,58,198,
28,0,82,0,112,0,109,0,71,0,97,0,117,0,103,0,
101,0,83,0,116,0,121,0,108,0,101,0,46,0,113,0,
109,0,108,0,10,2,209,16,60,0,83,0,116,0,121,0,
108,0,101,0,115,0,46,0,113,0,109,0,108,0,10,5,
153,222,92,0,85,0,110,0,108,0,111,0,99,0,107,0,
46,0,113,0,109,0,108,0,12,0,188,27,21,0,104,0,
105,0,103,0,104,0,95,0,118,0,111,0,108,0,116,0,
97,0,103,0,101,0,12,7,81,165,124,0,84,0,114,0,
97,0,99,0,116,0,105,0,111,0,110,0,46,0,113,0,
109,0,108,0,12,7,31,49,60,0,83,0,116,0,101,0,
101,0,114,0,105,0,110,0,103,0,46,0,113,0,109,0,
108,0,9,8,24,199,60,0,66,0,114,0,97,0,107,0,
101,0,46,0,113,0,109,0,108,0,14,13,134,60,220,0,
80,0,97,0,114,0,97,0,109,0,101,0,116,0,101,0,
114,0,115,0,46,0,113,0,109,0,108,0,10,8,50,125,
147,0,112,0,97,0,114,0,97,0,109,0,101,0,116,0,
101,0,114,0,115,0,9,8,198,240,60,0,84,0,121,0,
114,0,101,0,115,0,46,0,113,0,109,0,108,0,7,15,
60,88,188,0,72,0,109,0,105,0,46,0,113,0,109,0,
108,0,11,8,228,225,188,0,71,0,101,0,110,0,101,0,
114,0,97,0,108,0,46,0,113,0,109,0,108,0,9,8,
144,200,124,0,65,0,108,0,97,0,114,0,109,0,46,0,
113,0,109,0,108,0,10,8,225,109,60,0,67,0,104,0,
97,0,114,0,103,0,101,0,46,0,113,0,109,0,108,0,
18,14,182,138,28,0,73,0,99,0,111,0,110,0,71,0,
97,0,117,0,103,0,101,0,83,0,116,0,121,0,108,0,
101,0,46,0,113,0,109,0,108,0,12,9,119,73,156,0,
67,0,104,0,97,0,114,0,103,0,105,0,110,0,103,0,
46,0,113,0,109,0,108};
static const unsigned char qt_resource_empty_payout[] = { 0, 0, 0, 0, 0 };
QT_BEGIN_NAMESPACE
extern Q_CORE_EXPORT bool qRegisterResourceData(int, const unsigned char *, const unsigned char *, const unsigned char *);
QT_END_NAMESPACE
namespace QmlCacheGeneratedCode {
namespace _qml_Charging_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_IconGaugeStyle_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_parameters_Charge_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_parameters_Alarm_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_Parameters_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_high_voltage_Brake_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _jbQuick_Charts_QChart_js { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_Unlock_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_style_Styles_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_icon_desc_ContactModel_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_History_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_digital_BcuDigital_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_DashboardGaugeStyle_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_history_AlarmStat_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_Boot_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_history_ChargeTrippedRecord_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_dashwindow_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_BatteryDeployment_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_high_voltage_Steering_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_history_VehicleInfoRecord_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_high_voltage_Traction_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_HmiDashboard_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_history_AlarmRecord_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_analog_BmsAnalog_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_analog_BcuAnalog_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_Tpms_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_history_CellAlarmRecord_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_IconDescription_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_BatteryStatus_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_style_RpmGaugeStyle_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_parameters_General_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_analog_VcuAnalog_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_LogOn_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_digital_Dcdc_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ValueSource_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_digital_BmsDigital_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_TachometerStyle_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _jbQuick_Charts_QChart_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_VehicleInfo_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_digital_VcuDigital_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_Diagnose_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_parameters_Hmi_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_TurnIndicator_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_digital_PcuDigital_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ecu_analog_PcuAnalog_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_PedalGaugeStyle_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_parameters_Tyres_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_icon_desc_ChargeModel_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_history_SystemLog_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}

}
namespace {
struct Registry {
    Registry();
    QHash<QString, const QQmlPrivate::CachedQmlUnit*> resourcePathToCachedUnit;
    static const QQmlPrivate::CachedQmlUnit *lookupCachedUnit(const QUrl &url);
};

Q_GLOBAL_STATIC(Registry, unitRegistry)


Registry::Registry() {
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/Charging.qml"), &QmlCacheGeneratedCode::_qml_Charging_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/IconGaugeStyle.qml"), &QmlCacheGeneratedCode::_qml_IconGaugeStyle_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/parameters/Charge.qml"), &QmlCacheGeneratedCode::_qml_parameters_Charge_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/parameters/Alarm.qml"), &QmlCacheGeneratedCode::_qml_parameters_Alarm_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/Parameters.qml"), &QmlCacheGeneratedCode::_qml_Parameters_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/high_voltage/Brake.qml"), &QmlCacheGeneratedCode::_qml_high_voltage_Brake_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/jbQuick/Charts/QChart.js"), &QmlCacheGeneratedCode::_jbQuick_Charts_QChart_js::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/Unlock.qml"), &QmlCacheGeneratedCode::_qml_Unlock_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/style/Styles.qml"), &QmlCacheGeneratedCode::_qml_style_Styles_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/icon_desc/ContactModel.qml"), &QmlCacheGeneratedCode::_qml_icon_desc_ContactModel_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/History.qml"), &QmlCacheGeneratedCode::_qml_History_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/digital/BcuDigital.qml"), &QmlCacheGeneratedCode::_qml_ecu_digital_BcuDigital_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/DashboardGaugeStyle.qml"), &QmlCacheGeneratedCode::_qml_DashboardGaugeStyle_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/history/AlarmStat.qml"), &QmlCacheGeneratedCode::_qml_history_AlarmStat_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/Boot.qml"), &QmlCacheGeneratedCode::_qml_Boot_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/history/ChargeTrippedRecord.qml"), &QmlCacheGeneratedCode::_qml_history_ChargeTrippedRecord_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/dashwindow.qml"), &QmlCacheGeneratedCode::_qml_dashwindow_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/BatteryDeployment.qml"), &QmlCacheGeneratedCode::_qml_BatteryDeployment_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/high_voltage/Steering.qml"), &QmlCacheGeneratedCode::_qml_high_voltage_Steering_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/history/VehicleInfoRecord.qml"), &QmlCacheGeneratedCode::_qml_history_VehicleInfoRecord_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/high_voltage/Traction.qml"), &QmlCacheGeneratedCode::_qml_high_voltage_Traction_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/HmiDashboard.qml"), &QmlCacheGeneratedCode::_qml_HmiDashboard_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/history/AlarmRecord.qml"), &QmlCacheGeneratedCode::_qml_history_AlarmRecord_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/analog/BmsAnalog.qml"), &QmlCacheGeneratedCode::_qml_ecu_analog_BmsAnalog_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/analog/BcuAnalog.qml"), &QmlCacheGeneratedCode::_qml_ecu_analog_BcuAnalog_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/Tpms.qml"), &QmlCacheGeneratedCode::_qml_Tpms_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/history/CellAlarmRecord.qml"), &QmlCacheGeneratedCode::_qml_history_CellAlarmRecord_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/IconDescription.qml"), &QmlCacheGeneratedCode::_qml_IconDescription_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/BatteryStatus.qml"), &QmlCacheGeneratedCode::_qml_BatteryStatus_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/style/RpmGaugeStyle.qml"), &QmlCacheGeneratedCode::_qml_style_RpmGaugeStyle_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/parameters/General.qml"), &QmlCacheGeneratedCode::_qml_parameters_General_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/analog/VcuAnalog.qml"), &QmlCacheGeneratedCode::_qml_ecu_analog_VcuAnalog_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/LogOn.qml"), &QmlCacheGeneratedCode::_qml_LogOn_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/digital/Dcdc.qml"), &QmlCacheGeneratedCode::_qml_ecu_digital_Dcdc_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ValueSource.qml"), &QmlCacheGeneratedCode::_qml_ValueSource_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/digital/BmsDigital.qml"), &QmlCacheGeneratedCode::_qml_ecu_digital_BmsDigital_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/TachometerStyle.qml"), &QmlCacheGeneratedCode::_qml_TachometerStyle_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/jbQuick/Charts/QChart.qml"), &QmlCacheGeneratedCode::_jbQuick_Charts_QChart_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/VehicleInfo.qml"), &QmlCacheGeneratedCode::_qml_VehicleInfo_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/digital/VcuDigital.qml"), &QmlCacheGeneratedCode::_qml_ecu_digital_VcuDigital_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/Diagnose.qml"), &QmlCacheGeneratedCode::_qml_Diagnose_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/parameters/Hmi.qml"), &QmlCacheGeneratedCode::_qml_parameters_Hmi_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/TurnIndicator.qml"), &QmlCacheGeneratedCode::_qml_TurnIndicator_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/digital/PcuDigital.qml"), &QmlCacheGeneratedCode::_qml_ecu_digital_PcuDigital_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ecu/analog/PcuAnalog.qml"), &QmlCacheGeneratedCode::_qml_ecu_analog_PcuAnalog_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/PedalGaugeStyle.qml"), &QmlCacheGeneratedCode::_qml_PedalGaugeStyle_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/parameters/Tyres.qml"), &QmlCacheGeneratedCode::_qml_parameters_Tyres_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/icon_desc/ChargeModel.qml"), &QmlCacheGeneratedCode::_qml_icon_desc_ChargeModel_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/history/SystemLog.qml"), &QmlCacheGeneratedCode::_qml_history_SystemLog_qml::unit);
    QQmlPrivate::RegisterQmlUnitCacheHook registration;
    registration.version = 0;
    registration.lookupCachedQmlUnit = &lookupCachedUnit;
    QQmlPrivate::qmlregister(QQmlPrivate::QmlUnitCacheHookRegistration, &registration);
QT_PREPEND_NAMESPACE(qRegisterResourceData)(/*version*/0x01, qt_resource_tree, qt_resource_names, qt_resource_empty_payout);
}
const QQmlPrivate::CachedQmlUnit *Registry::lookupCachedUnit(const QUrl &url) {
    if (url.scheme() != QLatin1String("qrc"))
        return nullptr;
    QString resourcePath = QDir::cleanPath(url.path());
    if (resourcePath.isEmpty())
        return nullptr;
    if (!resourcePath.startsWith(QLatin1Char('/')))
        resourcePath.prepend(QLatin1Char('/'));
    return unitRegistry()->resourcePathToCachedUnit.value(resourcePath, nullptr);
}
}
int QT_MANGLE_NAMESPACE(qInitResources_dashboard)() {
    ::unitRegistry();
    Q_INIT_RESOURCE(dashboard_qmlcache);
    return 1;
}
Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_dashboard))
int QT_MANGLE_NAMESPACE(qCleanupResources_dashboard)() {
    Q_CLEANUP_RESOURCE(dashboard_qmlcache);
    return 1;
}
