/****************************************************************************
** Meta object code from reading C++ file 'worker.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../worker.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'worker.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Worker_t {
    QByteArrayData data[49];
    char stringdata0[591];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Worker_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Worker_t qt_meta_stringdata_Worker = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Worker"
QT_MOC_LITERAL(1, 7, 11), // "resultReady"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 6), // "result"
QT_MOC_LITERAL(4, 27, 5), // "error"
QT_MOC_LITERAL(5, 33, 3), // "err"
QT_MOC_LITERAL(6, 37, 8), // "finished"
QT_MOC_LITERAL(7, 46, 15), // "signalTickSlope"
QT_MOC_LITERAL(8, 62, 19), // "signalAccelerometer"
QT_MOC_LITERAL(9, 82, 20), // "signalLogVehicleInfo"
QT_MOC_LITERAL(10, 103, 21), // "signalSyncGpsTimeToHw"
QT_MOC_LITERAL(11, 125, 6), // "doWork"
QT_MOC_LITERAL(12, 132, 7), // "process"
QT_MOC_LITERAL(13, 140, 4), // "quit"
QT_MOC_LITERAL(14, 145, 18), // "cppSlotRaiseWindow"
QT_MOC_LITERAL(15, 164, 3), // "msg"
QT_MOC_LITERAL(16, 168, 17), // "cppSlotDeployment"
QT_MOC_LITERAL(17, 186, 5), // "index"
QT_MOC_LITERAL(18, 192, 11), // "updateModel"
QT_MOC_LITERAL(19, 204, 14), // "onSignalActive"
QT_MOC_LITERAL(20, 219, 16), // "onSignalCANFrame"
QT_MOC_LITERAL(21, 236, 8), // "can_addr"
QT_MOC_LITERAL(22, 245, 13), // "QCanBusFrame*"
QT_MOC_LITERAL(23, 259, 6), // "pframe"
QT_MOC_LITERAL(24, 266, 18), // "onSignalErrorFrame"
QT_MOC_LITERAL(25, 285, 9), // "direction"
QT_MOC_LITERAL(26, 295, 4), // "stat"
QT_MOC_LITERAL(27, 300, 10), // "rx_err_cnt"
QT_MOC_LITERAL(28, 311, 10), // "tx_err_cnt"
QT_MOC_LITERAL(29, 322, 21), // "onSignalLoadCompleted"
QT_MOC_LITERAL(30, 344, 14), // "onSignalUnlock"
QT_MOC_LITERAL(31, 359, 4), // "item"
QT_MOC_LITERAL(32, 364, 6), // "unlock"
QT_MOC_LITERAL(33, 371, 13), // "onSignalReset"
QT_MOC_LITERAL(34, 385, 23), // "onAlarmParameterChecked"
QT_MOC_LITERAL(35, 409, 3), // "row"
QT_MOC_LITERAL(36, 413, 3), // "col"
QT_MOC_LITERAL(37, 417, 7), // "checked"
QT_MOC_LITERAL(38, 425, 12), // "onSignalAuth"
QT_MOC_LITERAL(39, 438, 22), // "onSignalSessionTimeout"
QT_MOC_LITERAL(40, 461, 7), // "seconds"
QT_MOC_LITERAL(41, 469, 17), // "onSignalCalibrate"
QT_MOC_LITERAL(42, 487, 12), // "onSignalZero"
QT_MOC_LITERAL(43, 500, 16), // "onSignalTicksSec"
QT_MOC_LITERAL(44, 517, 9), // "n_seconds"
QT_MOC_LITERAL(45, 527, 11), // "onTickSlope"
QT_MOC_LITERAL(46, 539, 21), // "onSignalAccelerometer"
QT_MOC_LITERAL(47, 561, 11), // "onSignalGPS"
QT_MOC_LITERAL(48, 573, 17) // "onSyncGpsTimeToHw"

    },
    "Worker\0resultReady\0\0result\0error\0err\0"
    "finished\0signalTickSlope\0signalAccelerometer\0"
    "signalLogVehicleInfo\0signalSyncGpsTimeToHw\0"
    "doWork\0process\0quit\0cppSlotRaiseWindow\0"
    "msg\0cppSlotDeployment\0index\0updateModel\0"
    "onSignalActive\0onSignalCANFrame\0"
    "can_addr\0QCanBusFrame*\0pframe\0"
    "onSignalErrorFrame\0direction\0stat\0"
    "rx_err_cnt\0tx_err_cnt\0onSignalLoadCompleted\0"
    "onSignalUnlock\0item\0unlock\0onSignalReset\0"
    "onAlarmParameterChecked\0row\0col\0checked\0"
    "onSignalAuth\0onSignalSessionTimeout\0"
    "seconds\0onSignalCalibrate\0onSignalZero\0"
    "onSignalTicksSec\0n_seconds\0onTickSlope\0"
    "onSignalAccelerometer\0onSignalGPS\0"
    "onSyncGpsTimeToHw"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Worker[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  159,    2, 0x06 /* Public */,
       4,    1,  162,    2, 0x06 /* Public */,
       6,    0,  165,    2, 0x06 /* Public */,
       7,    0,  166,    2, 0x06 /* Public */,
       8,    0,  167,    2, 0x06 /* Public */,
       9,    0,  168,    2, 0x06 /* Public */,
      10,    0,  169,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    0,  170,    2, 0x0a /* Public */,
      12,    0,  171,    2, 0x0a /* Public */,
      13,    0,  172,    2, 0x0a /* Public */,
      14,    1,  173,    2, 0x0a /* Public */,
      16,    2,  176,    2, 0x0a /* Public */,
      18,    0,  181,    2, 0x0a /* Public */,
      19,    1,  182,    2, 0x0a /* Public */,
      20,    2,  185,    2, 0x0a /* Public */,
      24,    4,  190,    2, 0x0a /* Public */,
      29,    1,  199,    2, 0x0a /* Public */,
      30,    2,  202,    2, 0x0a /* Public */,
      33,    1,  207,    2, 0x0a /* Public */,
      34,    3,  210,    2, 0x0a /* Public */,
      38,    1,  217,    2, 0x0a /* Public */,
      39,    1,  220,    2, 0x0a /* Public */,
      41,    1,  223,    2, 0x0a /* Public */,
      42,    1,  226,    2, 0x0a /* Public */,
      43,    1,  229,    2, 0x0a /* Public */,
      45,    0,  232,    2, 0x0a /* Public */,
      46,    0,  233,    2, 0x0a /* Public */,
      47,    0,  234,    2, 0x0a /* Public */,
      48,    0,  235,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   15,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 22,   21,   23,
    QMetaType::Void, QMetaType::UInt, QMetaType::UInt, QMetaType::UInt, QMetaType::UInt,   25,   26,   27,   28,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   31,   32,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Bool,   35,   36,   37,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::Int,   40,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::UInt,   44,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Worker::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Worker *_t = static_cast<Worker *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->resultReady((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->error((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->finished(); break;
        case 3: _t->signalTickSlope(); break;
        case 4: _t->signalAccelerometer(); break;
        case 5: _t->signalLogVehicleInfo(); break;
        case 6: _t->signalSyncGpsTimeToHw(); break;
        case 7: _t->doWork(); break;
        case 8: _t->process(); break;
        case 9: _t->quit(); break;
        case 10: _t->cppSlotRaiseWindow((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->cppSlotDeployment((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 12: _t->updateModel(); break;
        case 13: _t->onSignalActive((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->onSignalCANFrame((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< QCanBusFrame*(*)>(_a[2]))); break;
        case 15: _t->onSignalErrorFrame((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< uint(*)>(_a[2])),(*reinterpret_cast< uint(*)>(_a[3])),(*reinterpret_cast< uint(*)>(_a[4]))); break;
        case 16: _t->onSignalLoadCompleted((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: _t->onSignalUnlock((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 18: _t->onSignalReset((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->onAlarmParameterChecked((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 20: _t->onSignalAuth((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->onSignalSessionTimeout((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->onSignalCalibrate((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 23: _t->onSignalZero((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 24: _t->onSignalTicksSec((*reinterpret_cast< uint(*)>(_a[1]))); break;
        case 25: _t->onTickSlope(); break;
        case 26: _t->onSignalAccelerometer(); break;
        case 27: _t->onSignalGPS(); break;
        case 28: _t->onSyncGpsTimeToHw(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Worker::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Worker::resultReady)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Worker::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Worker::error)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Worker::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Worker::finished)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Worker::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Worker::signalTickSlope)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Worker::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Worker::signalAccelerometer)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Worker::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Worker::signalLogVehicleInfo)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Worker::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Worker::signalSyncGpsTimeToHw)) {
                *result = 6;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Worker::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_Worker.data,
    qt_meta_data_Worker,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Worker::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Worker::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Worker.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Worker::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 29;
    }
    return _id;
}

// SIGNAL 0
void Worker::resultReady(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Worker::error(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Worker::finished()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void Worker::signalTickSlope()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void Worker::signalAccelerometer()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void Worker::signalLogVehicleInfo()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void Worker::signalSyncGpsTimeToHw()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
