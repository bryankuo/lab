/****************************************************************************
** Meta object code from reading C++ file 'sja1000_api.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../can/sja1000_api.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sja1000_api.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SJA1000_Api_t {
    QByteArrayData data[9];
    char stringdata0[69];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SJA1000_Api_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SJA1000_Api_t qt_meta_stringdata_SJA1000_Api = {
    {
QT_MOC_LITERAL(0, 0, 11), // "SJA1000_Api"
QT_MOC_LITERAL(1, 12, 4), // "stop"
QT_MOC_LITERAL(2, 17, 0), // ""
QT_MOC_LITERAL(3, 18, 7), // "can_run"
QT_MOC_LITERAL(4, 26, 4), // "int*"
QT_MOC_LITERAL(5, 31, 3), // "pfh"
QT_MOC_LITERAL(6, 35, 15), // "receive_message"
QT_MOC_LITERAL(7, 51, 13), // "get_can_value"
QT_MOC_LITERAL(8, 65, 3) // "str"

    },
    "SJA1000_Api\0stop\0\0can_run\0int*\0pfh\0"
    "receive_message\0get_can_value\0str"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SJA1000_Api[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // methods: name, argc, parameters, tag, flags
       1,    0,   39,    2, 0x02 /* Public */,
       3,    0,   40,    2, 0x02 /* Public */,
       3,    1,   41,    2, 0x02 /* Public */,
       6,    0,   44,    2, 0x02 /* Public */,
       7,    1,   45,    2, 0x02 /* Public */,

 // methods: parameters
    QMetaType::Void,
    QMetaType::Int,
    QMetaType::Int, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::QString, QMetaType::QString,    8,

       0        // eod
};

void SJA1000_Api::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SJA1000_Api *_t = static_cast<SJA1000_Api *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->stop(); break;
        case 1: { int _r = _t->can_run();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 2: { int _r = _t->can_run((*reinterpret_cast< int*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 3: _t->receive_message(); break;
        case 4: { QString _r = _t->get_can_value((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject SJA1000_Api::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_SJA1000_Api.data,
    qt_meta_data_SJA1000_Api,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SJA1000_Api::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SJA1000_Api::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SJA1000_Api.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int SJA1000_Api::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
