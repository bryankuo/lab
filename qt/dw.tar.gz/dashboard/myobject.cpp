#include "myobject.h"

MyObject::MyObject(QObject *parent) : QObject(parent)
{

}
