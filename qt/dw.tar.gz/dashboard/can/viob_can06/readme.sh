#!/bin/bash
sudo minicom -s
ATI
ATH1
ATDP

# clear CAN H/W filter
# clear Flow control filter
STFAFC
