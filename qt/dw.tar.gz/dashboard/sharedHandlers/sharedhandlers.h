#ifndef SHAREDHANDLERS_H
#define SHAREDHANDLERS_H

#include "sharedhandlers_global.h"

class SHAREDHANDLERSSHARED_EXPORT SharedHandlers
{

public:
    SharedHandlers();
};

#endif // SHAREDHANDLERS_H
