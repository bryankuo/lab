#include "sharedhandlers.h"


SharedHandlers::SharedHandlers()
{
}
