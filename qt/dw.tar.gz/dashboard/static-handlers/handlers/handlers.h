#ifndef HANDLERS_H
#define HANDLERS_H


class Handlers
{

public:
    Handlers();
};

#endif // HANDLERS_H
