#!/bin/bash
for i in {1..8};
do
echo -e "            bcuIOStatus$i: \"\""
done

exit 0;
