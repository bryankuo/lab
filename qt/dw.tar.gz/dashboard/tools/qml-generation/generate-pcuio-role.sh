#!/bin/bash
for i in {1..8};
do
echo -e "            pcuIOStatus$i: \"\""
done

exit 0;
