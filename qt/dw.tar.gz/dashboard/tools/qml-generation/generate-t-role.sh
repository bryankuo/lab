#!/bin/bash
for i in {1..48};
do
echo -e "            bcuIOStatus$i: \"\""
done

exit 0;
