#!/bin/bash
for i in {1..168};
do
echo -e "            v$i: \"\""
done

exit 0;
