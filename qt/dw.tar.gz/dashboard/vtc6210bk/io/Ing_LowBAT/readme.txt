You need to insert the "NEXCOM_IO" driver when you want to use "Igni.c" file.
You can compile "Igni.c" file as below.
#gcc Igni.c -o Igni
Then you can get state of ignition and battery from this demo code.
