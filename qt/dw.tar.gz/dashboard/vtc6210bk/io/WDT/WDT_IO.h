int WDT_SetTimer(char);
int WDT_ClearTimer(void);

