int DelayON_Set(char);
int DelayOFF_Set(char);

