#ifndef IOWRAPPER_H
#define IOWRAPPER_H


class IOWrapper
{
public:
    IOWrapper();
    ~IOWrapper();
    int GPS_Power_Switch(int on);
};

#endif // IOWRAPPER_H
