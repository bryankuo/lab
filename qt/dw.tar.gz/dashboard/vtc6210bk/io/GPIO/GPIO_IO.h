int GPIOType_Set(char,char);
int GPO_Set(char,char);
int GPI_Get();
int GPIOType_Get();
