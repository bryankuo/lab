#!/bin/bash
cp NEXCOM_CAN1.ko /lib/modules/`uname -r`/kernel/drivers/char/
insmod NEXCOM_CAN1.ko
depmod -a
echo "NEXCOM_CAN1" > /etc/modules-load.d/NEXCOM_CAN1.conf
echo "Install success please reset your computer."
