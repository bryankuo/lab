#if 0
#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>

#endif

#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <termios.h>
#include <unistd.h>
#include <error.h>
#include <fcntl.h> //File control definitions

typedef struct _light_
{
	int enable;
	unsigned short addr;
	int is_on;
	int alarm;
	long double voltage;
	long double current;	
} light, *plight;

#define NUM_LIGHT 200
typedef struct _light_context_
{
	light lights[NUM_LIGHT];
	int num_light;
} light_context, *plight_context;

typedef struct _thread_context
{
	pthread_t thread;
	pthread_mutex_t mut;
	pthread_cond_t cond;
	int dismiss;
	int cmd; //1 write; 2 read;
} thread_context, *pthread_context;

typedef struct _gprs_context
{
	int id;
} gprs_context, *pgprs_context;

typedef struct _socket_thread_context
{
	thread_context t;
	gprs_context   g;
	light_context  l;
} simulator_context, *psimulator_context;

simulator_context context;

void load_light_configurations(void);

//int fwscanf(FILE *restrict stream, const wchar_t *restrict format, *int enable, *unsigned short addr, *int is_on, *int alarm, *long double voltage, *long double current);
//extern int fwscanf(FILE *restrict stream, const wchar_t *restrict format,...) __attribute__ ((format (scanf, 2, 3)));

int main(int argc, char *argv[])
{
	//int result = 0, i = 0;

	context.t.dismiss = 0;
	//context.s.is_ready = 0;
	//context.s.is_server_connected = 0;
	context.g.id = atoi(argv[1]);
	printf("[%03d]+ma8-9i simulator...\n", context.g.id);
	load_light_configurations();
	printf("[%03d]-ma8-9i simulator.\n", context.g.id);
    exit(0);	
}

void load_light_configurations(void)
{
	int result = 0; //i = 0;
	memset(&context.l, 0, sizeof(context.l));
	char fname [32] = {0};
	sprintf((char*)&fname, "%03d.txt", context.g.id);
	FILE* fin = fopen(fname, "r");	
	if( NULL != fin )
	{
		do{
			result = fwscanf(fin, L"%d\t%04X\t%d\t%d\t%Lf\t%Lf\n",
				&context.l.lights[context.l.num_light].enable,
				&context.l.lights[context.l.num_light].addr,
				&context.l.lights[context.l.num_light].is_on,
				&context.l.lights[context.l.num_light].alarm,
				&context.l.lights[context.l.num_light].voltage,
				&context.l.lights[context.l.num_light].current);
			if(result!=WEOF)
				context.l.num_light++;			
		}while(result!=WEOF && context.l.num_light<NUM_LIGHT);
	}
	/*for(i=0; i<context.l.num_light; i++)
	{
		printf("%d, %04X, %d, %-d, %.2f, %.2f\n",
			context.l.lights[i].enable,
			context.l.lights[i].addr,
			context.l.lights[i].is_on,
			context.l.lights[i].alarm,
			context.l.lights[i].voltage,
			context.l.lights[i].current
		);
	}*/
	printf("[%03d]num light loaded = %d\n", context.g.id, context.l.num_light);	
}