#if 0
#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>

#endif

#include <stdio.h>
#include <wchar.h>
#include <stdarg.h>

#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <termios.h>
#include <unistd.h>
#include <error.h>
#include <fcntl.h> //File control definitions
#include <sys/select.h>
#include <netinet/in.h>     // in_addr structure
#include <arpa/inet.h>

typedef struct _terminal_context
{
} terminal_context, *pterminal_context;

typedef struct _light_
{
	int enable;
	unsigned short addr;
	int is_on;
	int alarm;
	long double voltage;
	long double current;	
} light, *plight;

#define NUM_LIGHT 200
typedef struct _light_context_
{
	light lights[NUM_LIGHT];
	int num_light;
} light_context, *plight_context;

typedef struct _thread_context
{
	pthread_t thread;
	pthread_mutex_t mut;
	pthread_cond_t cond;
	int dismiss;
	int cmd; //1 write; 2 read;
} thread_context, *pthread_context;

typedef struct _socket_context
{
	int socketfds;
	struct sockaddr_in name;
	//address
	//port
	int is_ready;
	int is_server_connected;
	unsigned char rxbuffer[21];
	unsigned char txbuffer[21];
	int txlen;
} socket_context, *psocket_context;

typedef struct _gprs_context
{
	int id;
} gprs_context, *pgprs_context;

typedef struct _socket_thread_context
{
	thread_context t;
	socket_context s;
	gprs_context   g;
	light_context  l;
} simulator_context, *psimulator_context;

simulator_context context;

void *print_message_function( void *ptr );
void *print_socket_function( void *ptr );
unsigned char make_checksum(unsigned char* buffer, int len);
void set_alarm( int type, unsigned short addr );
void set_tx_buffer( const light* pl );
void load_light_configurations(void);

int main(int argc, char *argv[])
{
	int result = 0, i = 0;

    //pthread_t thread_tty;
	
    //char *message1 = "Thread 1 - message";
    //char *message2 = "Thread 2 - socket";
	//pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

	//int x,y;
	
    // Create independent threadfds each of which will execute function
    //int iret1 = pthread_create( &thread1, NULL, print_message_function, (void*) message1);
	// = PTHREAD_MUTEX_INITIALIZER;
	//context.t.cond = PTHREAD_COND_INITIALIZER;
	pthread_mutex_init(&context.t.mut, NULL);
	pthread_cond_init(&context.t.cond, NULL);
	context.t.dismiss = 0;
	context.s.is_ready = 0;
	context.s.is_server_connected = 0;
	context.g.id = atoi(argv[1]);
	printf("[%03d]+ma8-9i simulator...\n", context.g.id);
	load_light_configurations();
    int iret_socket = pthread_create( &context.t.thread, NULL, print_socket_function, (void*) &context );

	fd_set readfds;
	struct termios tio_org;
	struct termios tio_new;	
	tcgetattr(STDIN_FILENO, &tio_org);
	tio_new = tio_org;
	tio_new.c_iflag &= ~( BRKINT );
	tio_new.c_lflag |= ( ECHOE | ECHO | ICANON | ISIG);
	tcsetattr(STDIN_FILENO, TCSAFLUSH, &tio_new);
    int tty_in = dup(0);
	if(tty_in == -1)
	{
		error(-1, -1, "Can't open dup of stdin\n");
		exit(-1);
	}
	if(fcntl(tty_in, F_SETFL, O_NONBLOCK) == -1)
	{
		error(-1, -1, "Failed to set nonblocking stdin\n");
		exit(-1);
	}
	int b_end = 0;
	static struct timeval timeout;
	unsigned char command[35];
	int num_byte_read;
	int rc = 0, fd = 0;
	unsigned char addr[2];
	do{
		timeout.tv_sec = 10;
		timeout.tv_usec = 0;
		FD_ZERO(&readfds);
		FD_SET(tty_in, &readfds);		
		if( context.s.is_ready && FD_ISSET(context.s.socketfds, &readfds)<=0 )
		{
			FD_SET(context.s.socketfds, &readfds);
		}
		//printf("+select\n");
		result = select(FD_SETSIZE, &readfds, NULL, NULL, &timeout);
		//printf("-select\n");
		if(result < 0)
		{
			//printf("[%03d]select < 0\n", context.g.id);
			continue;
		}
		else if(result == 0)
		{
			//printf("[%03d]select timed out\n", context.g.id);
			//sleep(15);
			// kill lost socket, when time-out
			continue;
		}
		else
		{
			for(fd = 0; fd < 10; fd++)
			{				
				if( fd == tty_in && FD_ISSET(tty_in, &readfds))
				{
					num_byte_read = read(STDIN_FILENO, command, sizeof(command));
					if(num_byte_read > 0)
					{
						switch(command[0])
						{
							case 'q':
							case 'Q':
								printf("[%03d]quit ma8-9i simulation.\n", context.g.id);
								b_end = 1;
								//context.t.cmd = 0;
								context.t.dismiss = 1;
								rc = pthread_cond_signal(&context.t.cond);
								rc = pthread_mutex_unlock(&context.t.mut);
								break;
							case 'a':
							case 'A':
								memset(addr, 0, sizeof(addr));
								unsigned char strh[3] = {command[3], command[4], '\0'};
								unsigned char strl[3] = {command[5], command[6], '\0'};										
								sscanf(strh, "%02x", &addr[0]);	
								sscanf(strl, "%02x", &addr[1]);								
								unsigned short light_addr = 0;
								light_addr = ( ( light_addr | addr[0] )<<8 ) | addr[1];
								printf("[%03d]recv '%c%c %04x'\n", context.g.id, command[0], command[1], light_addr);
								for(i=0; i<context.l.num_light; i++)
									if( light_addr == context.l.lights[i].addr && 1 == context.l.lights[i].enable )
									{	
										if( '1' == command[1] || '2' == command[1] )
										{
											int type = command[1]-0x30;
											context.l.lights[i].alarm = 0-type;
											set_alarm(type, light_addr);
											context.t.cmd = 1;
											rc = pthread_cond_signal(&context.t.cond);
											rc = pthread_mutex_unlock(&context.t.mut); 						
											printf("[%03d]set alarm %04x\n", context.g.id, light_addr);										
										}
										break;
									}								
								
								break;
							default:
								printf("[%03d]recv cmd from tty ", context.g.id);
								for(i=0; i<num_byte_read; i++)
									printf("%c", command[i]);						
								printf("\n");								
								break;
						}				
					}
					else
					{
						printf("unknown read of 0 bytes!\n");
						continue;
					}				
				}
				if( fd == context.s.socketfds && FD_ISSET(context.s.socketfds, &readfds))
				{
					context.t.cmd = 2;
					rc = pthread_cond_signal(&context.t.cond);
					rc = pthread_mutex_unlock(&context.t.mut);
				}
			}
		}
	}while( b_end != 1 );
	
#if 0
	static struct timeval  timeout;		
	int j;
	int done = 0;
	int iCmdLen;
	int fd, nread;
	static char cLedResult[84];	
	do
	{
		timeout.tv_sec = 30;
		timeout.tv_usec = 0;
		FD_ZERO(&readfds);
		FD_SET(tty_in, &readfds);
		FD_SET(socketfds, &readfds);
		result = select(FD_SETSIZE, &readfds, NULL, NULL, &timeout);
		if(result < 0)
		{
			printf("select < 0");
			done = 1;
			continue;
		}
		else if(result == 0)
		{
			//printf("select timed out.\n");
			//sleep(15);
			// kill lost socket, when time-out
		}
		else
		{
			if(FD_ISSET(tty_in, &readfds))
			{
				printf("read data from tty...\n");
				num_byte_read = read(STDIN_FILENO,command,sizeof(command));
			
				
				if (command[0] == 'a')
				{
					memset(rxbuffer, 0x0, sizeof(rxbuffer));
				//  We can now read/write via socketfds.

			}
			printf("socket command sent...\n");
			for(fd = 0; fd < 10; fd++)
			{				
				if(FD_ISSET(fd,&readfds))
				{
					printf("read socket data...\n");
					printf("read on %d\n", fd);
					ioctl(fd, FIONREAD, &nread);
				}
			}
		}
		//sleep(1); // give the LED some time to respond
	}while (!done);
#endif
     /* Wait till threadfds are complete before main continues. Unless we  */
     /* wait we run the risk of executing an exit which will terminate   */
     /* the process and all threadfds before the threadfds have completed.   */
	iret_socket = pthread_join( context.t.thread, NULL );
	printf("[%03d]Thread 2 returns: %d\n", context.g.id, iret_socket );	
	result = pthread_mutex_destroy( &context.t.mut );
	result = pthread_cond_destroy( &context.t.cond );
	
    //pthread_join( thread1, NULL);
    //printf("Thread 1 returns: %d\n",iret1);
	close(tty_in);
	tcsetattr(STDIN_FILENO, TCSAFLUSH, &tio_org);	
	printf("[%03d]-ma8-9i simulator.\n", context.g.id);
    exit(0);	
}

void load_light_configurations(void)
{
	int result;
	char fname [32];
	
	result = 0; //i = 0;
	memset(&context.l, 0, sizeof(context.l));	
	memset(fname, 0, sizeof(fname));
	
	sprintf((char*)&fname, "%03d.txt", context.g.id);
	FILE* fin = fopen(fname, "r");	
	if( NULL != fin )
	{
		do{
			result = fwscanf(fin, L"%d\t%04X\t%d\t%d\t%Lf\t%Lf\n",
			//result = fscanf(fin, "%d\t%04X\t%d\t%d\t%Lf\t%Lf\n",
				&context.l.lights[context.l.num_light].enable,
				&context.l.lights[context.l.num_light].addr,
				&context.l.lights[context.l.num_light].is_on,
				&context.l.lights[context.l.num_light].alarm,
				&context.l.lights[context.l.num_light].voltage,
				&context.l.lights[context.l.num_light].current);
			if(result!=WEOF)
				context.l.num_light++;			
		}while(result!=WEOF && context.l.num_light<NUM_LIGHT);
	}
	/*for(i=0; i<context.l.num_light; i++)
	{
		printf("%d, %04X, %d, %-d, %.2f, %.2f\n",
			context.l.lights[i].enable,
			context.l.lights[i].addr,
			context.l.lights[i].is_on,
			context.l.lights[i].alarm,
			context.l.lights[i].voltage,
			context.l.lights[i].current
		);
	}*/
	printf("[%03d]num light loaded = %d\n", context.g.id, context.l.num_light);	
}

unsigned char make_checksum(unsigned char* buffer, int len)
{
	unsigned char chksum = 0;
	int i = 0;
	for(i=0; i<len; i++)
	{		
		chksum = chksum ^ *(buffer+i);
	}
	return chksum;
}

void set_alarm( int type, unsigned short addr )
{
	psimulator_context pctx = (simulator_context *)&context;
	//printf("[%03d]+set_alarm\n", pctx->g.id);
	memset(pctx->s.txbuffer, 0x0, sizeof(pctx->s.txbuffer));
	pctx->s.txbuffer[0] = 0xa3;
	pctx->s.txbuffer[1] = 0x38;
	pctx->s.txbuffer[2] = 0x00;
	pctx->s.txbuffer[3] = 0x2e;
	pctx->s.txbuffer[4] = 0x06;
	pctx->s.txbuffer[5] = 0xdc;
	pctx->s.txbuffer[6] = (unsigned char)((0xFF00&addr)>>8);
	pctx->s.txbuffer[7] = (unsigned char)((0x00FF&addr));
	pctx->s.txbuffer[8] = (unsigned char)type;//0x01;
	pctx->s.txbuffer[9] = 0x00;
	pctx->s.txbuffer[10] = 0x11;
	pctx->s.txbuffer[11] = make_checksum(pctx->s.txbuffer, 11);
	pctx->s.txlen = 12;
	//printf("[%03d]-set_alarm\n", pctx->g.id);
}					

void set_tx_buffer( const light* pl )
{
	//printf("[%03d]+set_tx_buffer\n");
	psimulator_context pctx = (simulator_context *)&context;
	memset(pctx->s.txbuffer, 0x0, sizeof(pctx->s.txbuffer));
	
	//printf("0x%02x 0x%02x\n", addr[0], addr[1]);
	pctx->s.txbuffer[0] = 0xa1;
	pctx->s.txbuffer[1] = 0x5a;
	pctx->s.txbuffer[2] = (unsigned char)((0xFF00&pl->addr)>>8); //*paddr; //command[2]; //0x00;
	pctx->s.txbuffer[3] = (unsigned char)((0x00FF&pl->addr)); //*(paddr+1); //command[3]; //0x08;
	pctx->s.txbuffer[4] = 0x0f;
	pctx->s.txbuffer[5] = 0xdb;
	long double v = 0.0;
	v = ((pl->voltage/96.6353)*1023)/3.30;
	unsigned short adc1 = (unsigned short)v;
	pctx->s.txbuffer[6] = (unsigned char)((0xFF00&adc1)>>8);
	pctx->s.txbuffer[7] = (unsigned char)(0x00FF&adc1);
	long double c = 0.0;
	c = ((pl->current/2.2779)*1023)/3.30;
	unsigned short adc2 = (unsigned short)c;
	pctx->s.txbuffer[8] = (unsigned char)((0xFF00&adc2)>>8);
	pctx->s.txbuffer[9] = (unsigned char)(0x00FF&adc2);
	pctx->s.txbuffer[10] = 0x01;
	pctx->s.txbuffer[11] = 0xc2;
	pctx->s.txbuffer[12] = 0x00;
	pctx->s.txbuffer[13] = 0x04;
	pctx->s.txbuffer[14] = 0x00;
	pctx->s.txbuffer[15] = 0x04;
	pctx->s.txbuffer[16] = 0x00;
	pctx->s.txbuffer[17] = 0x00;
	pctx->s.txbuffer[18] = 0x41;
	pctx->s.txbuffer[19] = 0x84;
	pctx->s.txbuffer[20] = make_checksum(pctx->s.txbuffer, 20);
	pctx->t.cmd = 1;
	pctx->s.txlen = 21;	
	//printf("[%03d]-set_tx_buffer\n");
}
					
void *print_message_function( void *ptr )
{
	printf("+print_message_function\n");
    //char *message;
    //message = (char *) ptr;
	//cv* pcv = (cv*)ptr;
	while(1)
	{		
		//printf("%s \n", message);
		printf("pend... \n");
		sleep(2);
		printf("post... \n");
	}
	printf("-print_message_function\n");
	return NULL;
}

void *print_socket_function( void *ptr )
{
	//printf("+print_socket_function\n");	
	psimulator_context pctx = (simulator_context *)ptr;	
	int num_trial = 0, is_connect = 0, num_byte_read = 0, num_byte_write = 0, i = 0;
	static int num_times_read = 0;
	static int num_times_write = 0;
	static int num_light_set = 0;
	do{
		//printf("+creating socket...\n");
		pctx->s.socketfds = socket(AF_INET, SOCK_STREAM, 0);
		if( pctx->s.socketfds < 0 )
		{
           perror("err create socket, retrying...\n");
        }
		else
		{
			pctx->s.name.sin_family = AF_INET;
			pctx->s.name.sin_addr.s_addr = inet_addr("127.0.0.1");
			pctx->s.name.sin_port = htons(9636);
			if( -1 == connect(pctx->s.socketfds, (struct sockaddr *)&pctx->s.name, sizeof(pctx->s.name)) )
			{
				printf("err connect, retrying...\n");
			}
			else
			{
				is_connect = 1;
				break;
			}		
		}
		//printf("-creating socket...\n");
		num_trial++;
		sleep(1);
	}while( /*0 == is_connect &&*/ num_trial < 999 );
	pctx->s.is_ready = 1;
	while(!pctx->t.dismiss)
	{
		//printf("%s \n", message);
		//printf("[%03d]pend... \n", pctx->g.id);
		pthread_mutex_lock(&pctx->t.mut);
		pthread_cond_wait(&pctx->t.cond, &pctx->t.mut);
		pthread_mutex_unlock(&pctx->t.mut);
		if( pctx->t.cmd <= 0 ) continue;
		switch( pctx->t.cmd )
		{
			case 1:				
				num_byte_write = write(pctx->s.socketfds, pctx->s.txbuffer, pctx->s.txlen);	//sizeof(rxbuffer));
				if( num_byte_write > 0 )
				{
					printf("[%03d]write %d\n", pctx->g.id, num_byte_write);
				}
				else{}
				num_times_write++;
				break;
			case 2:				
				memset(pctx->s.rxbuffer, 0, sizeof(pctx->s.rxbuffer));
				num_byte_read = read(pctx->s.socketfds, pctx->s.rxbuffer, sizeof(pctx->s.rxbuffer));
				if( num_byte_read > 0 )
				{
					if(!strncasecmp((const char *)pctx->s.rxbuffer, "Welcome!!!", sizeof("Welcome!!!")))
					{
						printf("[%03d]check literal from daemon ok.\n", pctx->g.id);
						memset(pctx->s.txbuffer, 0x0, sizeof(pctx->s.txbuffer));
						sprintf((char*)pctx->s.txbuffer, "ID=%03d", pctx->g.id);
						num_byte_write = write(pctx->s.socketfds, pctx->s.txbuffer, 6);
						if( num_byte_write > 0 )
						{
							pctx->s.is_server_connected = 1;
						}
					}
					else
					{
						switch( pctx->s.rxbuffer[5] )
						{
							case 0xda:
								num_light_set = 0;
								printf("[%03d]light control(0x%02x 0x%02x%02x 0x%02x%02x)...\n", pctx->g.id, pctx->s.rxbuffer[6], pctx->s.rxbuffer[7], pctx->s.rxbuffer[8], pctx->s.rxbuffer[9], pctx->s.rxbuffer[10]);
								if( (pctx->s.rxbuffer[9]==0x00 && pctx->s.rxbuffer[10]==0x00) || (pctx->s.rxbuffer[9]==0x01 && pctx->s.rxbuffer[10]==0x01) )
								{
									if (pctx->s.rxbuffer[9]==0x00 && pctx->s.rxbuffer[10]==0x00) i = 1; else i = 0;
									switch(pctx->s.rxbuffer[6])
									{
										case 0x00:
											for(i=0; i<pctx->l.num_light; i++)
												if( 1 == pctx->l.lights[i].enable )
												{
													pctx->l.lights[i].is_on = i;
													if( i == 1 )
													num_light_set++;
												}									
										break;
										case 0x01:
											for(i=0; i<pctx->l.num_light; i++)
												if( (pctx->l.lights[i].addr&0x0001)==1 && 1 == pctx->l.lights[i].enable )
												{
													pctx->l.lights[i].is_on = i;
													num_light_set++;
												}										
										break;
										case 0x02:
											for(i=0; i<pctx->l.num_light; i++)
												if( (pctx->l.lights[i].addr&0x0001)==0 && 1 == pctx->l.lights[i].enable )
												{
													pctx->l.lights[i].is_on = i;
													num_light_set++;												
												}
										break;
										case 0x03:
										for(i=0; i<pctx->l.num_light; i++)
											if( ((pctx->l.lights[i].addr&0xFF00)>>8)==pctx->s.rxbuffer[7] && (pctx->l.lights[i].addr&0x00FF)==pctx->s.rxbuffer[8] && 1 == pctx->l.lights[i].enable )
											{
												pctx->l.lights[i].is_on = i;
												num_light_set++;
												break;
											}
										break;
									}
									printf("[%03d]num of light set %s = %d\n", pctx->g.id, (i==1)?"on":"off", num_light_set);
								}
							break;
							case 0xdb:
								num_light_set = 0;
								printf("[%03d]inquire parameter(0x%02x 0x%02x%02x)...\n", pctx->g.id, pctx->s.rxbuffer[6], pctx->s.rxbuffer[7], pctx->s.rxbuffer[8]);
								switch(pctx->s.rxbuffer[6])
								{
									case 0x00:
										for(i=0; i<pctx->l.num_light; i++)
											if( 1 == pctx->l.lights[i].enable )
											{
												set_tx_buffer( &pctx->l.lights[i] );
												num_byte_write = write(pctx->s.socketfds, pctx->s.txbuffer, pctx->s.txlen);
												//printf("[%03d]write %d\n", pctx->g.id, num_byte_write);
												num_light_set++;
											}
									break;
									case 0x01:
										for(i=0; i<pctx->l.num_light; i++)
											if( (pctx->l.lights[i].addr&0x0001)==1 && 1 == pctx->l.lights[i].enable )
											{
												set_tx_buffer( &pctx->l.lights[i] );
												num_byte_write = write(pctx->s.socketfds, pctx->s.txbuffer, pctx->s.txlen);
												//printf("[%03d]write %d\n", pctx->g.id, num_byte_write);
												num_light_set++;										
											}
									break;
									case 0x02:
										for(i=0; i<pctx->l.num_light; i++)
											if( (pctx->l.lights[i].addr&0x0001)==0 && 1 == pctx->l.lights[i].enable )
											{
												set_tx_buffer( &pctx->l.lights[i] );
												num_byte_write = write(pctx->s.socketfds, pctx->s.txbuffer, pctx->s.txlen);
												//printf("[%03d]write %d\n", pctx->g.id, num_byte_write);
												num_light_set++;										
											}							
									break;
									case 0x03:
										for(i=0; i<pctx->l.num_light; i++)
											if( ((pctx->l.lights[i].addr&0xFF00)>>8)==pctx->s.rxbuffer[7] && (pctx->l.lights[i].addr&0x00FF)==pctx->s.rxbuffer[8] && 1 == pctx->l.lights[i].enable )
											{
												set_tx_buffer( &pctx->l.lights[i] );
												num_byte_write = write(pctx->s.socketfds, pctx->s.txbuffer, pctx->s.txlen);
												//printf("[%03d]write %d\n", pctx->g.id, num_byte_write);
												num_light_set++;
												break;
											}
									break;
								}
								printf("[%03d]num of light replied = %d\n", pctx->g.id, num_light_set);
							break;
							case 0xdd:
								num_light_set = 0;
								printf("[%03d]stop alarm(0x%02x 0x%02x%02x)...\n", pctx->g.id, pctx->s.rxbuffer[6], pctx->s.rxbuffer[7], pctx->s.rxbuffer[8]);
								switch(pctx->s.rxbuffer[6])
								{
									case 0x00:
										for(i=0; i<pctx->l.num_light; i++)
											if( 1 == pctx->l.lights[i].enable && pctx->l.lights[i].alarm != 0 )
											{
												pctx->l.lights[i].alarm = 0;
												num_light_set++;
											}
									break;
									case 0x01:
										for(i=0; i<pctx->l.num_light; i++)
											if( (pctx->l.lights[i].addr&0x0001)==1 && 1 == pctx->l.lights[i].enable && pctx->l.lights[i].alarm != 0 )
											{
												pctx->l.lights[i].alarm = 0;
												num_light_set++;
											}
									break;
									case 0x02:
										for(i=0; i<pctx->l.num_light; i++)
											if( (pctx->l.lights[i].addr&0x0001)==0 && 1 == pctx->l.lights[i].enable && pctx->l.lights[i].alarm != 0 )
											{
												pctx->l.lights[i].alarm = 0;
												num_light_set++;
											}							
									break;
									case 0x03:
										for(i=0; i<pctx->l.num_light; i++)
											if( ((pctx->l.lights[i].addr&0xFF00)>>8)==pctx->s.rxbuffer[7] && (pctx->l.lights[i].addr&0x00FF)==pctx->s.rxbuffer[8] && 1 == pctx->l.lights[i].enable && pctx->l.lights[i].alarm != 0 )
											{
												pctx->l.lights[i].alarm = 0;
												num_light_set++;
												break;
											}
									break;
								}
								printf("[%03d]num of light stop alarm = %d\n", pctx->g.id, num_light_set);								
							break;							
							case 0xde:							
								num_light_set = 0;
								printf("[%03d]reset alarm(0x%02x 0x%02x%02x)...\n", pctx->g.id, pctx->s.rxbuffer[6], pctx->s.rxbuffer[7], pctx->s.rxbuffer[8]);
								switch(pctx->s.rxbuffer[6])
								{
									case 0x00:
										for(i=0; i<pctx->l.num_light; i++)
											if( 1 == pctx->l.lights[i].enable && pctx->l.lights[i].alarm != 0 )
											{
												pctx->l.lights[i].alarm = 0;
												pctx->l.lights[i].is_on = 0;
												pctx->l.lights[i].voltage = 0;
												pctx->l.lights[i].current = 0;												
												num_light_set++;
											}
									break;
									case 0x01:
										for(i=0; i<pctx->l.num_light; i++)
											if( (pctx->l.lights[i].addr&0x0001)==1 && 1 == pctx->l.lights[i].enable && pctx->l.lights[i].alarm != 0 )
											{
												pctx->l.lights[i].alarm = 0;
												pctx->l.lights[i].is_on = 0;
												pctx->l.lights[i].voltage = 0;
												pctx->l.lights[i].current = 0;												
												num_light_set++;
											}
									break;
									case 0x02:
										for(i=0; i<pctx->l.num_light; i++)
											if( (pctx->l.lights[i].addr&0x0001)==0 && 1 == pctx->l.lights[i].enable && pctx->l.lights[i].alarm != 0 )
											{
												pctx->l.lights[i].alarm = 0;
												pctx->l.lights[i].is_on = 0;
												pctx->l.lights[i].voltage = 0;
												pctx->l.lights[i].current = 0;												
												num_light_set++;
											}							
									break;
									case 0x03:
										for(i=0; i<pctx->l.num_light; i++)
											if( ((pctx->l.lights[i].addr&0xFF00)>>8)==pctx->s.rxbuffer[7] && (pctx->l.lights[i].addr&0x00FF)==pctx->s.rxbuffer[8] && 1 == pctx->l.lights[i].enable && pctx->l.lights[i].alarm != 0 )
											{
												pctx->l.lights[i].alarm = 0;
												pctx->l.lights[i].is_on = 0;
												pctx->l.lights[i].voltage = 0;
												pctx->l.lights[i].current = 0;												
												num_light_set++;
												break;
											}
									break;
								}
								printf("[%03d]num of light stop alarm = %d\n", pctx->g.id, num_light_set);															
							break;							
							default:
								for(i=0; i<num_byte_read; i++)
									printf("0x%02x ", pctx->s.rxbuffer[i]);						
								printf("\n");							
							break;
						}
						//handle_incoming_data(pctx->s.rxbuffer, num_byte_read);						
					}
				}
				else {}
				num_times_read++;
				printf("[%03d]n_read = %d, len = %d\n", pctx->g.id, num_times_read, num_byte_read);
				break;
			default:
				printf("[%03d]post... \n", pctx->g.id);
				break;
		}		
	}	
	int ret;
	ret = close(pctx->s.socketfds/*, 0*/);	
	pctx->s.is_server_connected = 0;
	pctx->s.is_ready = 0;
	//printf("-print_socket_function\n");
	return NULL;
}