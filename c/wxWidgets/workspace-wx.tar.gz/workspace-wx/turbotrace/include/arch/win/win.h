//This will prevent the winsock redifinition errors which happen because windows.h includes winsock.h LOL
#ifndef WIN32_LEAN_AND_MEAN 
#define WIN32_LEAN_AND_MEAN
#endif

